common_py
=====

common_py is the fundamental package needed for common purpose with Python.

Requirements
-------

* Python &ge; 3.7
* Toolz &ge; 0.10.0

Install
-------

```shell
pip install common-py
```
